#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <QGLWidget>
#include <QKeyEvent>
#include <QColor>
#include <QVector2D>
#include"GL/gl.h"

// Classe dediee a l'affichage d'une scene OpenGL
class MyGLWidget : public QGLWidget
{
    Q_OBJECT

public:

    // Constructeur
    MyGLWidget(QWidget * parent = nullptr);

protected:

    // Fonction d'initialisation
    void initializeGL();

    // Fonction de redimensionnement
    void resizeGL(int width, int height);

    // Fonction d'affichage
    void paintGL();

    // Fonction de gestion d'interactions clavier
    void keyPressEvent(QKeyEvent * event);

    void glTranslatefR();
    void glTranslatefL();
    void glTranslatefB();
    void glTranslatefH();

private:
    // Quelques variables a definir
    // variable couleur primitive
    float red;
    float blue;
    float green;
    // couleur fond
    float redBackground;
    float blueBackground;
    float greenBackground;
    // changer de primitive
    bool space;
    //cacher la primitive
    bool hide;
    //coordonnées
    GLfloat x = 0.5;
    GLfloat y = 0.5;
    GLfloat rotate  = 0;
};

#endif // MYGLWIDGET_H
