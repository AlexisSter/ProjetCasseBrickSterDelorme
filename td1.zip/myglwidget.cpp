#include "myglwidget.h"
#include <QApplication>
#include <QDesktopWidget>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>

// Declarations des constantes
const unsigned int WIN_WIDTH  = 1300;
const unsigned int WIN_HEIGHT = 600;
const float ASPECT_RATIO      = static_cast<float>(WIN_WIDTH) / WIN_HEIGHT;
const float ORTHO_DIM         = 50.0f;


// Constructeur
MyGLWidget::MyGLWidget(QWidget * parent) : QGLWidget(parent)
{
    // Reglage de la taille/position
    setFixedSize(WIN_WIDTH, WIN_HEIGHT);
    move(QApplication::desktop()->screen()->rect().center() - rect().center());
    red = 0.0;
    green = 0.0;
    blue = 255.0;

    redBackground = 0.5;
    blueBackground = 0.5;
    greenBackground = 0.5;

    space = true;

    hide = false;
}


// Fonction d'initialisation
void MyGLWidget::initializeGL()
{
    // Reglage de la couleur de fond
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
}


// Fonction de redimensionnement
void MyGLWidget::resizeGL(int width, int height)
{
    // Definition du viewport (zone d'affichage)
    glViewport(0,0,1300,600);
    // Definition de la matrice de projection
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-ORTHO_DIM * ASPECT_RATIO, ORTHO_DIM * ASPECT_RATIO, -ORTHO_DIM, ORTHO_DIM, -2.0f * ORTHO_DIM, 2.0f * ORTHO_DIM);

    // Definition de la matrice de modele
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


// Fonction d'affichage
void MyGLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT);


    // Reinitialisation du tampon de couleur

    // Reinitialisation de la matrice courante
    glColor3ub(red, green, blue);  // Couleur à utiliser pour dessiner les objets

    // Définir la zone à afficher
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);

    glRotated(rotate,0,0,1);

    if(!hide)
    {
        if(space)
          {
              glBegin(GL_TRIANGLES); // Primitive à afficher et début de la déclaration des vertices de cette primitive
              glVertex2f(x, y+0.25);  // Définition des coordonnées des sommets (en 2D, z=0)
              glVertex2f(x-0.25, y-0.25);
             glVertex2f(x+0.25, y-0.25);
              glEnd(); // Fin de la définition de la primitive
        }
         else
         {
           glBegin(GL_QUADS); // Primitive à afficher et début de la déclaration des vertices de cette primitive
           glVertex2f(x-0.25, x-0.25);  // Définition des coordonnées des sommets (en 2D, z=0)
           glVertex2f(x+0.25, x-0.25);
          glVertex2f(x+0.25, x+0.25);
          glVertex2f(x-0.25, x+0.25);
         glEnd();
     }
    }
    // Reglage de la couleur

    // Debut de l'affichage

}


// Fonction de gestion d'interactions clavier
void MyGLWidget::keyPressEvent(QKeyEvent * event)
{
    switch(event->key())
    {
        // Changement de couleur du fond
        case Qt::Key_B:
        {
             redBackground = (float)rand()/RAND_MAX;
             blueBackground = (float)rand()/RAND_MAX;
             greenBackground = (float)rand()/RAND_MAX;
             glClearColor(redBackground, blueBackground, greenBackground, 1.0f);
            break;
        }

        // Changement de couleur de l'objet
        case Qt::Key_C:
        {
            red = rand();
            blue = rand();
            green = rand();
            break;
        }

        // Affichage/Masquage de l'objet
        case Qt::Key_H:
        {
            hide =  !hide;
            break;
        }

        // Changement de l'objet a afficher
        case Qt::Key_Space:
        {
            space = !space;
            break;
        }

        // Sortie de l'application
        case Qt::Key_Escape:
        {
            close();
            break;
        }
         case Qt::Key_Left:
         {
             glTranslatefL();
             break;
         }
        case Qt::Key_Right:
         {
          glTranslatefR();
          break;
         }
         case Qt::Key_Up:
        {
            glTranslatefH();
         break;
         }
         case Qt::Key_Down:
          {
         glTranslatefB();
          break;
           }

    case Qt::Key_R:
    {
        rotate = rotate + 5;
        break;
    }
        // Cas par defaut
        default:
        {
            // Ignorer l'evenement
            event->ignore();
            return;
        }
    }

    // Acceptation de l'evenement et mise a jour de la scene
    event->accept();
    updateGL();
}

void MyGLWidget::glTranslatefL()
{
    x = x - 0.05;
}

void MyGLWidget::glTranslatefR()
{
    x = x + 0.05;
}

void MyGLWidget::glTranslatefH()
{
    y = y + 0.05;
}

void MyGLWidget::glTranslatefB()
{
    y = y - 0.05;
}
